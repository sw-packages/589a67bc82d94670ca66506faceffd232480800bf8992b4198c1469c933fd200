/// @deprecated Include @c <pqxx/params> instead.

#include "params.hxx"
